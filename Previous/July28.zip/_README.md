# My-Junks
This repo included junks that I need to go back to every now and then.


## Files included:
* [Rcodes.md](https://github.com/xiaojiezhou/My-Junks/blob/master/RCodes.md):  Example of R codes
* [MyRfunctions.md](https://github.com/xiaojiezhou/My-Junks/blob/master/MyRFunctions.md):  My R functions
* [MyNLPFunctions.md] (https://github.com/xiaojiezhou/My-Junks/blob/master/MyNLPFunctions.md):  My NLP R functions
* [Github.md](https://github.com/xiaojiezhou/My-Junks/blob/master/Github.md):  Git commands and markdown examples




